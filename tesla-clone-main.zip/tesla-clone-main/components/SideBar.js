export const SideBar = [
    {
        title: "Model S",
        path: "/",
        cName: "sideText"
    },
    {
        title: "Model 3",
        path: "/",
        cName: "sideText"
    },
    {
        title: "Model X",
        path: "/",
        cName: "sideText"
    },
    {
        title: "Solar Roof",
        path: "/",
        cName: "sideText"
    },
    {
        title: "Solar Panels",
        path: "/",
        cName: "sideText"
    },
    {
        title: "Existing Inventory",
        path: "/",
        cName: "sideText"
    },
    {
        title: "Used Inventory",
        path: "/",
        cName: "sideText"
    }
]